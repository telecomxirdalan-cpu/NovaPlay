# NovaPlay

Premium gaming discovery platform foundation.

## Current build

- Next.js + TypeScript
- Premium dark NovaPlay design system
- Responsive navbar and mobile menu
- Homepage
- Games catalog
- Search
- Genre browsing
- Game detail routes
- Favorites/profile/news/reviews placeholders
- API route foundation
- Environment variable template

## Run

```bash
npm install
npm run dev
```

## Important

The visible starter catalog is intentionally small. It is NOT the final 2000+ production database.

The production data pipeline must use a licensed/authorized game data source (planned: IGDB), normalize and validate records server-side, cache them, and store them in PostgreSQL. Do not invent missing ratings, release dates, screenshots, or system requirements.

## Next implementation phase

1. PostgreSQL + Prisma schema
2. IGDB server integration
3. Initial 2000+ real-game ingestion
4. Redis caching
5. Server-side pagination/filtering/sorting
6. Dynamic metadata/SEO
7. Authentication and persistent favorites
8. Editorial news/review CMS
