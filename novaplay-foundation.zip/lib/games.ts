export type Game = {
  id: number;
  slug: string;
  name: string;
  genre: string;
  year: number;
  rating: number | null;
  cover: string;
  description: string;
};

export const games: Game[] = [
  {
    id: 1,
    slug: "cyberpunk-2077",
    name: "Cyberpunk 2077",
    genre: "RPG",
    year: 2020,
    rating: 8.7,
    cover: "https://images.igdb.com/igdb/image/upload/t_cover_big/co2lb5.jpg",
    description: "An open-world action RPG set in Night City."
  },
  {
    id: 2,
    slug: "elden-ring",
    name: "Elden Ring",
    genre: "RPG",
    year: 2022,
    rating: 9.4,
    cover: "https://images.igdb.com/igdb/image/upload/t_cover_big/co4jni.jpg",
    description: "A vast fantasy action RPG built around exploration and discovery."
  },
  {
    id: 3,
    slug: "grand-theft-auto-v",
    name: "Grand Theft Auto V",
    genre: "Action",
    year: 2013,
    rating: 9.1,
    cover: "https://images.igdb.com/igdb/image/upload/t_cover_big/co2lbd.jpg",
    description: "An open-world action game set in Los Santos."
  },
  {
    id: 4,
    slug: "red-dead-redemption-2",
    name: "Red Dead Redemption 2",
    genre: "Adventure",
    year: 2018,
    rating: 9.5,
    cover: "https://images.igdb.com/igdb/image/upload/t_cover_big/co1q1f.jpg",
    description: "An expansive western adventure from Rockstar Games."
  },
  {
    id: 5,
    slug: "the-witcher-3-wild-hunt",
    name: "The Witcher 3: Wild Hunt",
    genre: "RPG",
    year: 2015,
    rating: 9.2,
    cover: "https://images.igdb.com/igdb/image/upload/t_cover_big/co1wyy.jpg",
    description: "A story-driven open-world fantasy RPG."
  },
  {
    id: 6,
    slug: "minecraft",
    name: "Minecraft",
    genre: "Sandbox",
    year: 2011,
    rating: 9.0,
    cover: "https://images.igdb.com/igdb/image/upload/t_cover_big/co49x5.jpg",
    description: "A sandbox game centered on building, exploration and creativity."
  }
];