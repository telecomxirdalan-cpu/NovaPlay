import type { Metadata } from "next";
import "./globals.css";
import { Navbar } from "@/components/navbar";

export const metadata: Metadata = {
  title: {
    default: "NovaPlay — Future of Gaming Discovery",
    template: "%s — NovaPlay"
  },
  description: "Discover real games, ratings, platforms, genres and upcoming releases with NovaPlay.",
  metadataBase: new URL("https://novaplay.com"),
  openGraph: {
    title: "NovaPlay — Future of Gaming Discovery",
    description: "A premium gaming discovery platform.",
    type: "website"
  }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <Navbar />
        {children}
      </body>
    </html>
  );
}