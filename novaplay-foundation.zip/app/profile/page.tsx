export default function ProfilePage() {
  return (
    <main className="min-h-screen bg-[#070A12]">
      <div className="mx-auto max-w-4xl px-5 py-20">
        <p className="text-xs font-semibold uppercase tracking-[.22em] text-[#25D9FF]">Account</p>
        <h1 className="mt-2 text-4xl font-black">Profile</h1>
        <div className="mt-8 rounded-2xl border border-white/10 bg-[#101625] p-6 text-[#B8C0D4]">Authentication will be connected in the next build phase.</div>
      </div>
    </main>
  );
}