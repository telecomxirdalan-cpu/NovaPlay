import Link from "next/link";

export default function NotFound() {
  return (
    <main className="np-grid np-glow grid min-h-[80vh] place-items-center bg-[#070A12] px-5 text-center">
      <div>
        <div className="text-8xl font-black tracking-[-.08em] np-text-gradient">404</div>
        <h1 className="mt-5 text-3xl font-black">Game Over?</h1>
        <p className="mx-auto mt-3 max-w-md text-[#78839A]">The page you’re looking for could not be found.</p>
        <Link href="/" className="np-gradient mt-7 inline-flex rounded-xl px-5 py-3 font-semibold">Return to NovaPlay</Link>
      </div>
    </main>
  );
}