export default function NewsPage() {
  return (
    <main className="min-h-screen bg-[#070A12]">
      <div className="mx-auto max-w-7xl px-5 py-14 lg:px-8">
        <p className="text-xs font-semibold uppercase tracking-[.22em] text-[#25D9FF]">Editorial</p>
        <h1 className="mt-2 text-4xl font-black tracking-tight sm:text-5xl">Gaming News</h1>
        <div className="mt-10 rounded-3xl border border-white/10 bg-[#101625] p-8">
          <h2 className="text-2xl font-bold">News infrastructure is ready for the next phase.</h2>
          <p className="mt-3 max-w-2xl text-[#B8C0D4]">The production version will connect verified news sources through a dedicated editorial/content pipeline. No invented news will be published.</p>
        </div>
      </div>
    </main>
  );
}