import Link from "next/link";
import { games } from "@/lib/games";

export default function GenresPage() {
  const genres = Array.from(new Set(games.map(g => g.genre)));
  return (
    <main className="min-h-screen bg-[#070A12]">
      <div className="mx-auto max-w-7xl px-5 py-14 lg:px-8">
        <p className="text-xs font-semibold uppercase tracking-[.22em] text-[#25D9FF]">Explore</p>
        <h1 className="mt-2 text-4xl font-black tracking-tight sm:text-5xl">Genres</h1>
        <p className="mt-3 max-w-xl text-[#B8C0D4]">Browse the catalog by play style.</p>
        <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {genres.map(genre => (
            <Link key={genre} href={`/games?genre=${encodeURIComponent(genre)}`} className="group np-card p-6 transition hover:-translate-y-1 hover:border-[#7C5CFF]/50">
              <div className="text-xl font-bold">{genre}</div>
              <div className="mt-2 text-sm text-[#78839A]">{games.filter(g => g.genre === genre).length} games</div>
            </Link>
          ))}
        </div>
      </div>
    </main>
  );
}