export default function FavoritesPage() {
  return (
    <main className="min-h-screen bg-[#070A12]">
      <div className="mx-auto max-w-4xl px-5 py-20 text-center">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-[#7C5CFF]/10 text-[#9278FF]">♡</div>
        <h1 className="mt-6 text-3xl font-black">Your library is empty.</h1>
        <p className="mx-auto mt-3 max-w-md text-[#78839A]">Save games you want to remember. Account sync will be enabled in the authentication phase.</p>
      </div>
    </main>
  );
}