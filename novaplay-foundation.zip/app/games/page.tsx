 "use client";

import { useMemo, useState } from "react";
import { Search, SlidersHorizontal } from "lucide-react";
import { games } from "@/lib/games";
import { GameCard } from "@/components/game-card";

export default function GamesPage() {
  const [query, setQuery] = useState("");
  const [genre, setGenre] = useState("All");
  const genres = ["All", ...Array.from(new Set(games.map(g => g.genre)))];

  const filtered = useMemo(() => games.filter(g =>
    (genre === "All" || g.genre === genre) &&
    g.name.toLowerCase().includes(query.toLowerCase())
  ), [query, genre]);

  return (
    <main className="min-h-screen bg-[#070A12]">
      <div className="mx-auto max-w-7xl px-5 py-12 lg:px-8">
        <div className="mb-8">
          <p className="text-xs font-semibold uppercase tracking-[.22em] text-[#25D9FF]">Database</p>
          <h1 className="mt-2 text-4xl font-black tracking-tight sm:text-5xl">Games</h1>
          <p className="mt-3 max-w-2xl text-[#B8C0D4]">Explore the NovaPlay catalog. The production data layer will replace this starter dataset with the full real-game API sync.</p>
        </div>

        <div className="mb-8 grid gap-3 md:grid-cols-[1fr_auto]">
          <label className="flex h-12 items-center gap-3 rounded-xl border border-white/10 bg-[#101625] px-4">
            <Search size={19} className="text-[#78839A]"/>
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search games..." className="w-full bg-transparent outline-none placeholder:text-[#78839A]"/>
          </label>
          <div className="flex items-center gap-2 overflow-x-auto">
            <SlidersHorizontal size={18} className="shrink-0 text-[#78839A]"/>
            {genres.map(item => (
              <button key={item} onClick={() => setGenre(item)} className={`whitespace-nowrap rounded-xl border px-4 py-2.5 text-sm ${genre === item ? "border-[#7C5CFF] bg-[#7C5CFF]/15 text-white" : "border-white/10 bg-[#101625] text-[#B8C0D4]"}`}>
                {item}
              </button>
            ))}
          </div>
        </div>

        {filtered.length ? (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
            {filtered.map(game => <GameCard key={game.id} game={game} />)}
          </div>
        ) : (
          <div className="rounded-2xl border border-white/10 bg-[#101625] px-6 py-16 text-center">
            <h2 className="text-xl font-bold">No matches found.</h2>
            <p className="mt-2 text-[#78839A]">Try another title or genre.</p>
          </div>
        )}
      </div>
    </main>
  );
}