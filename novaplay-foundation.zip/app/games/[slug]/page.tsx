import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Heart, Star } from "lucide-react";
import { games } from "@/lib/games";

export function generateStaticParams() {
  return games.map(game => ({ slug: game.slug }));
}

export default async function GamePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const game = games.find(g => g.slug === slug);
  if (!game) notFound();

  return (
    <main className="min-h-screen bg-[#070A12]">
      <section className="relative overflow-hidden border-b border-white/5">
        <div className="absolute inset-0">
          <img src={game.cover} alt="" className="h-full w-full scale-110 object-cover opacity-20 blur-2xl" />
          <div className="absolute inset-0 bg-[#070A12]/80" />
        </div>
        <div className="relative mx-auto max-w-7xl px-5 py-10 lg:px-8 lg:py-16">
          <Link href="/games" className="mb-10 inline-flex items-center gap-2 text-sm text-[#B8C0D4] hover:text-white"><ArrowLeft size={16}/> Back to games</Link>
          <div className="grid gap-10 md:grid-cols-[260px_1fr] lg:grid-cols-[320px_1fr]">
            <img src={game.cover} alt={game.name} className="w-full rounded-2xl border border-white/10 shadow-2xl" />
            <div className="self-end">
              <div className="mb-3 flex flex-wrap gap-2">
                <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-[#B8C0D4]">{game.genre}</span>
                <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-[#B8C0D4]">{game.year}</span>
              </div>
              <h1 className="max-w-3xl text-4xl font-black tracking-tight sm:text-6xl">{game.name}</h1>
              <div className="mt-5 flex flex-wrap items-center gap-4 text-[#B8C0D4]">
                {game.rating !== null && <span className="flex items-center gap-1"><Star size={16} className="fill-current text-[#FFB84D]"/>{game.rating}</span>}
                <span>Rating source: external game database</span>
              </div>
              <p className="mt-6 max-w-2xl text-base leading-7 text-[#B8C0D4]">{game.description}</p>
              <button className="mt-7 inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-5 py-3 font-semibold hover:bg-white/10"><Heart size={18}/> Add to favorites</button>
            </div>
          </div>
        </div>
      </section>
      <div className="mx-auto grid max-w-7xl gap-6 px-5 py-12 lg:grid-cols-[1fr_340px] lg:px-8">
        <section className="np-card p-6">
          <h2 className="text-2xl font-bold">About the game</h2>
          <p className="mt-4 leading-7 text-[#B8C0D4]">{game.description}</p>
        </section>
        <aside className="np-card h-fit p-6">
          <h2 className="text-lg font-bold">Game information</h2>
          <dl className="mt-5 grid gap-4 text-sm">
            <div><dt className="text-[#78839A]">Genre</dt><dd className="mt-1">{game.genre}</dd></div>
            <div><dt className="text-[#78839A]">Release year</dt><dd className="mt-1">{game.year}</dd></div>
            <div><dt className="text-[#78839A]">Developer</dt><dd className="mt-1 text-[#B8C0D4]">Not available</dd></div>
            <div><dt className="text-[#78839A]">Publisher</dt><dd className="mt-1 text-[#B8C0D4]">Not available</dd></div>
            <div><dt className="text-[#78839A]">System requirements</dt><dd className="mt-1 text-[#B8C0D4]">Not available</dd></div>
          </dl>
        </aside>
      </div>
    </main>
  );
}