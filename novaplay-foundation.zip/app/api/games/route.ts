import { NextResponse } from "next/server";
import { games } from "@/lib/games";

export async function GET() {
  // Production: replace this starter source with the server-side
  // IGDB ingestion/cache layer. Never expose IGDB credentials here.
  return NextResponse.json({
    data: games,
    meta: { page: 1, pageSize: games.length, source: "starter-dataset" }
  });
}