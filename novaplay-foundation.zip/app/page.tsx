import Link from "next/link";
import { ArrowRight, Play, Search, Star } from "lucide-react";
import { games } from "@/lib/games";
import { GameSection } from "@/components/section";

export default function Home() {
  const featured = games[1];
  return (
    <main className="np-grid np-glow min-h-screen">
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_40%,rgba(124,92,255,.20),transparent_36%)]" />
        <div className="mx-auto grid min-h-[650px] max-w-7xl items-center gap-10 px-5 py-14 lg:grid-cols-[1.05fr_.95fr] lg:px-8">
          <div className="relative z-10">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-[#B8C0D4] backdrop-blur">
              <span className="h-1.5 w-1.5 rounded-full bg-[#25D9FF] shadow-[0_0_12px_#25D9FF]" />
              Future of Gaming Discovery
            </div>
            <h1 className="max-w-3xl text-5xl font-black leading-[.98] tracking-[-.045em] sm:text-6xl lg:text-7xl">
              Discover your next <span className="np-text-gradient">great game.</span>
            </h1>
            <p className="mt-6 max-w-xl text-base leading-7 text-[#B8C0D4] sm:text-lg">
              Explore real games, ratings, genres, platforms and upcoming releases in one fast, premium gaming database.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/games" className="np-gradient inline-flex items-center gap-2 rounded-xl px-5 py-3 font-semibold text-white shadow-lg shadow-[#7C5CFF]/15">
                Explore games <ArrowRight size={18}/>
              </Link>
              <Link href="/search" className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-5 py-3 font-semibold text-white backdrop-blur hover:bg-white/10">
                <Search size={18}/> Search
              </Link>
            </div>
            <div className="mt-10 flex gap-8 text-sm">
              <div><div className="text-2xl font-bold">2000+</div><div className="text-[#78839A]">Real games</div></div>
              <div><div className="text-2xl font-bold">∞</div><div className="text-[#78839A]">Discoveries</div></div>
            </div>
          </div>
          <div className="relative">
            <div className="absolute -inset-8 rounded-[40px] bg-[#7C5CFF]/10 blur-3xl" />
            <div className="relative overflow-hidden rounded-[28px] border border-white/10 bg-[#101625] shadow-2xl">
              <img src={featured.cover} alt={featured.name} className="aspect-[4/5] w-full object-cover sm:aspect-[5/6] lg:aspect-[4/5]" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-transparent to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-6 sm:p-8">
                <div className="mb-2 text-xs font-semibold uppercase tracking-[.2em] text-[#25D9FF]">Featured</div>
                <h2 className="text-3xl font-black sm:text-4xl">{featured.name}</h2>
                <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-[#B8C0D4]">
                  <span className="flex items-center gap-1"><Star size={15} className="fill-current text-[#FFB84D]"/>{featured.rating}</span>
                  <span>{featured.genre}</span><span>{featured.year}</span>
                </div>
                <p className="mt-3 max-w-lg text-sm leading-6 text-[#B8C0D4]">{featured.description}</p>
                <Link href={`/games/${featured.slug}`} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-bold text-[#070A12]"><Play size={16} className="fill-current"/> View game</Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-5 pb-16 lg:px-8">
        <GameSection title="Trending Games" games={games} />
        <GameSection title="Top Rated" games={[...games].sort((a,b)=>(b.rating ?? 0)-(a.rating ?? 0))} />
        <GameSection title="Recently Released" games={[...games].sort((a,b)=>b.year-a.year)} />
        <section className="py-10">
          <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-[#101625] to-[#0B1020] p-8 sm:p-12">
            <p className="text-xs font-semibold uppercase tracking-[.22em] text-[#25D9FF]">Explore</p>
            <h2 className="mt-3 max-w-2xl text-3xl font-bold tracking-tight sm:text-4xl">Find games by the way you play.</h2>
            <p className="mt-4 max-w-xl text-[#B8C0D4]">Action, RPG, horror, racing, strategy and more — browse the NovaPlay catalog your way.</p>
            <Link href="/genres" className="mt-7 inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-5 py-3 font-semibold hover:bg-white/10">Browse genres <ArrowRight size={17}/></Link>
          </div>
        </section>
      </div>
    </main>
  );
}