 "use client";

import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import Link from "next/link";
import { games } from "@/lib/games";

export default function SearchPage() {
  const [q, setQ] = useState("");
  const results = useMemo(() => q.trim() ? games.filter(g => g.name.toLowerCase().includes(q.toLowerCase())) : [], [q]);
  return (
    <main className="min-h-screen bg-[#070A12]">
      <div className="mx-auto max-w-4xl px-5 py-16 lg:px-8">
        <p className="text-xs font-semibold uppercase tracking-[.22em] text-[#25D9FF]">Search</p>
        <h1 className="mt-2 text-4xl font-black tracking-tight">Find your next game.</h1>
        <div className="mt-8 flex items-center gap-3 rounded-2xl border border-white/10 bg-[#101625] px-5 py-4">
          <Search className="text-[#78839A]" />
          <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="Search games, genres, developers..." className="w-full bg-transparent text-lg outline-none placeholder:text-[#78839A]" />
        </div>
        <div className="mt-8 grid gap-2">
          {results.map(game => (
            <Link key={game.id} href={`/games/${game.slug}`} className="flex items-center justify-between rounded-xl border border-white/5 bg-[#101625] p-4 hover:border-[#7C5CFF]/40">
              <div><div className="font-semibold">{game.name}</div><div className="mt-1 text-sm text-[#78839A]">{game.genre} · {game.year}</div></div>
              <span className="text-sm text-[#B8C0D4]">{game.rating ?? "N/A"}</span>
            </Link>
          ))}
          {q && !results.length && <div className="py-12 text-center text-[#78839A]">No matches found.</div>}
        </div>
      </div>
    </main>
  );
}