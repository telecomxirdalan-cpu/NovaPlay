 "use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, Search, Heart, UserRound, X } from "lucide-react";
import { Logo } from "./logo";

const links = [
  ["Home", "/"],
  ["Games", "/games"],
  ["Genres", "/genres"],
  ["News", "/news"],
  ["Reviews", "/reviews"]
];

export function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-white/5 bg-[#070A12]/85 backdrop-blur-xl">
      <div className="mx-auto flex h-18 max-w-7xl items-center justify-between px-5 lg:px-8">
        <Logo />
        <nav className="hidden items-center gap-7 md:flex">
          {links.map(([label, href]) => (
            <Link key={href} href={href} className="text-sm text-[#B8C0D4] transition hover:text-white">
              {label}
            </Link>
          ))}
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          <Link href="/search" aria-label="Search" className="grid h-10 w-10 place-items-center rounded-xl text-[#B8C0D4] hover:bg-white/5 hover:text-white"><Search size={19}/></Link>
          <Link href="/favorites" aria-label="Favorites" className="grid h-10 w-10 place-items-center rounded-xl text-[#B8C0D4] hover:bg-white/5 hover:text-white"><Heart size={19}/></Link>
          <Link href="/profile" aria-label="Profile" className="grid h-10 w-10 place-items-center rounded-xl text-[#B8C0D4] hover:bg-white/5 hover:text-white"><UserRound size={19}/></Link>
        </div>
        <button onClick={() => setOpen(!open)} className="grid h-10 w-10 place-items-center rounded-xl md:hidden" aria-label="Toggle menu">
          {open ? <X size={21}/> : <Menu size={21}/>}
        </button>
      </div>
      {open && (
        <div className="border-t border-white/5 bg-[#0B1020] px-5 py-4 md:hidden">
          <div className="grid gap-1">
            {links.map(([label, href]) => (
              <Link onClick={() => setOpen(false)} key={href} href={href} className="rounded-xl px-3 py-3 text-[#B8C0D4] hover:bg-white/5 hover:text-white">{label}</Link>
            ))}
            <Link href="/search" className="rounded-xl px-3 py-3 text-[#B8C0D4] hover:bg-white/5 hover:text-white">Search</Link>
            <Link href="/favorites" className="rounded-xl px-3 py-3 text-[#B8C0D4] hover:bg-white/5 hover:text-white">Favorites</Link>
          </div>
        </div>
      )}
    </header>
  );
}