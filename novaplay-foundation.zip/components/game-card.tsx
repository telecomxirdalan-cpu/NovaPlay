import Link from "next/link";
import { Heart, Star } from "lucide-react";
import type { Game } from "@/lib/games";

export function GameCard({ game }: { game: Game }) {
  return (
    <Link href={`/games/${game.slug}`} className="group block">
      <article className="np-card overflow-hidden transition duration-300 hover:-translate-y-1 hover:border-[#7C5CFF]/50">
        <div className="relative aspect-[3/4] overflow-hidden bg-[#101625]">
          <img src={game.cover} alt={`${game.name} cover`} loading="lazy" className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.035]" />
          <button
            onClick={(e) => e.preventDefault()}
            aria-label={`Add ${game.name} to favorites`}
            className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full border border-white/10 bg-black/45 text-white backdrop-blur-md"
          >
            <Heart size={17}/>
          </button>
          <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#0B1020] to-transparent" />
        </div>
        <div className="p-4">
          <div className="mb-2 flex items-center justify-between gap-3">
            <h3 className="truncate font-semibold">{game.name}</h3>
            {game.rating !== null && <span className="flex shrink-0 items-center gap-1 text-xs text-[#B8C0D4]"><Star size={13} className="fill-current text-[#FFB84D]"/>{game.rating}</span>}
          </div>
          <div className="flex items-center justify-between text-xs text-[#78839A]">
            <span>{game.genre}</span><span>{game.year}</span>
          </div>
        </div>
      </article>
    </Link>
  );
}