import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { GameCard } from "./game-card";
import type { Game } from "@/lib/games";

export function GameSection({ title, games, href = "/games" }: { title: string; games: Game[]; href?: string }) {
  return (
    <section className="py-10">
      <div className="mb-5 flex items-end justify-between gap-4">
        <div>
          <p className="mb-2 text-xs font-semibold uppercase tracking-[0.22em] text-[#78839A]">NovaPlay</p>
          <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">{title}</h2>
        </div>
        <Link href={href} className="flex items-center gap-1 text-sm font-semibold text-[#B8C0D4] hover:text-white">View all <ArrowUpRight size={16}/></Link>
      </div>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
        {games.slice(0, 6).map((game) => <GameCard key={game.id} game={game} />)}
      </div>
    </section>
  );
}