import Link from "next/link";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" aria-label="NovaPlay home" className="flex items-center gap-3">
      <span className="relative grid h-10 w-10 place-items-center overflow-hidden rounded-xl border border-white/10 bg-[#101625]">
        <span className="absolute inset-0 opacity-80 np-gradient" />
        <span className="relative font-black tracking-[-0.12em] text-white">NP</span>
      </span>
      {!compact && <span className="font-bold tracking-tight text-lg">NovaPlay</span>}
    </Link>
  );
}